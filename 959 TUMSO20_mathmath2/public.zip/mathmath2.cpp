#include <iostream>
#include "mathmath2.h"

using namespace std;

int N;

int main()
{
    N = init();

    long long g = GCD(0, 1);
    answer({0, 1});
}