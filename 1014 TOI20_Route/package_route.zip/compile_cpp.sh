#!/bin/bash
g++ -std=c++11 -Wall -O2 -static -pipe grader.cpp route.cpp -o route
