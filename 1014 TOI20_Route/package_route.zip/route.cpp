#include <vector>
#include <utility>

std::vector<std::pair<int, int>> route(int N, std::vector<int> W) {
    std::vector<std::pair<int, int>> ans;
    // edit this
    return ans;
}