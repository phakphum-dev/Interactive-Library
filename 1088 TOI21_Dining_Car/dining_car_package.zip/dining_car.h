#include <utility>

std::pair<int, int> locate_dining_cars(int N);

int compare_cars(int i, int j);
