#include <bits/stdc++.h>
#include "dining_car.h"

using namespace std;

// you can also write additional functions here

pair < int, int > locate_dining_cars(int N) 
{
  //write your code here

  //you can call "compare_cars(i,j)"

  return make_pair(-1, -1);
}
