#include <vector>

// you can write more function here

int minimum_bag_rearrangement_time(std::vector<int> max_allowed_positions) {
  //write your code here
  return 0;
}
