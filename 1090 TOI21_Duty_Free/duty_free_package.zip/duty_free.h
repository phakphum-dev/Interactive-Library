#include <vector>

int minimum_bag_rearrangement_time(std::vector<int> max_allowed_positions);