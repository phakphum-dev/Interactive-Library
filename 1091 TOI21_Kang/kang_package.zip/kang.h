#include <vector>

std::vector<long long> capsize(std::vector<int> A, std::vector<int> B);
