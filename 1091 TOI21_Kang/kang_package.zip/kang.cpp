#include <vector>

std::vector<long long> capsize(std::vector<int> A, std::vector<int> B) {
  //write your code here

  return std::vector<long long>();
}
